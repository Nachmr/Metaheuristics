echo "Greedy"

./qap 1 Datos/chr20b.dat 4312365
./qap 1 Datos/chr20c.dat 4312365
./qap 1 Datos/chr22a.dat 4312365
./qap 1 Datos/chr22b.dat 4312365
./qap 1 Datos/els19.dat 4312365
./qap 1 Datos/esc32b.dat 4312365
./qap 1 Datos/kra30b.dat 4312365
./qap 1 Datos/lipa90b.dat 4312365
./qap 1 Datos/nug30.dat 4312365
./qap 1 Datos/sko56.dat 4312365
./qap 1 Datos/sko64.dat 4312365
./qap 1 Datos/sko72.dat 4312365
./qap 1 Datos/sko81.dat 4312365
./qap 1 Datos/sko90.dat 4312365
./qap 1 Datos/sko100a.dat 4312365
./qap 1 Datos/sko100b.dat 4312365
./qap 1 Datos/sko100c.dat 4312365
./qap 1 Datos/sko100d.dat 4312365
./qap 1 Datos/sko100e.dat 4312365
./qap 1 Datos/wil50.dat 4312365
echo "BMB"

./qap 2 Datos/chr20b.dat 4312365
./qap 2 Datos/chr20c.dat 4312365
./qap 2 Datos/chr22a.dat 4312365
./qap 2 Datos/chr22b.dat 4312365
./qap 2 Datos/els19.dat 4312365
./qap 2 Datos/esc32b.dat 4312365
./qap 2 Datos/kra30b.dat 4312365
./qap 2 Datos/lipa90b.dat 4312365
./qap 2 Datos/nug30.dat 4312365
./qap 2 Datos/sko56.dat 4312365
./qap 2 Datos/sko64.dat 4312365
./qap 2 Datos/sko72.dat 4312365
./qap 2 Datos/sko81.dat 4312365
./qap 2 Datos/sko90.dat 4312365
./qap 2 Datos/sko100a.dat 4312365
./qap 2 Datos/sko100b.dat 4312365
./qap 2 Datos/sko100c.dat 4312365
./qap 2 Datos/sko100d.dat 4312365
./qap 2 Datos/sko100e.dat 4312365
./qap 2 Datos/wil50.dat 4312365

echo "GRASP"

./qap 3 Datos/chr20b.dat 4312365
./qap 3 Datos/chr20c.dat 4312365
./qap 3 Datos/chr22a.dat 4312365
./qap 3 Datos/chr22b.dat 4312365
./qap 3 Datos/els19.dat 4312365
./qap 3 Datos/esc32b.dat 4312365
./qap 3 Datos/kra30b.dat 4312365
./qap 3 Datos/lipa90b.dat 4312365
./qap 3 Datos/nug30.dat 4312365
./qap 3 Datos/sko56.dat 4312365
./qap 3 Datos/sko64.dat 4312365
./qap 3 Datos/sko72.dat 4312365
./qap 3 Datos/sko81.dat 4312365
./qap 3 Datos/sko90.dat 4312365
./qap 3 Datos/sko100a.dat 4312365
./qap 3 Datos/sko100b.dat 4312365
./qap 3 Datos/sko100c.dat 4312365
./qap 3 Datos/sko100d.dat 4312365
./qap 3 Datos/sko100e.dat 4312365
./qap 3 Datos/wil50.dat 4312365

echo "ISL"

./qap 4 Datos/chr20b.dat 4312365
./qap 4 Datos/chr20c.dat 4312365
./qap 4 Datos/chr22a.dat 4312365
./qap 4 Datos/chr22b.dat 4312365
./qap 4 Datos/els19.dat 4312365
./qap 4 Datos/esc32b.dat 4312365
./qap 4 Datos/kra30b.dat 4312365
./qap 4 Datos/lipa90b.dat 4312365
./qap 4 Datos/nug30.dat 4312365
./qap 4 Datos/sko56.dat 4312365
./qap 4 Datos/sko64.dat 4312365
./qap 4 Datos/sko72.dat 4312365
./qap 4 Datos/sko81.dat 4312365
./qap 4 Datos/sko90.dat 4312365
./qap 4 Datos/sko100a.dat 4312365
./qap 4 Datos/sko100b.dat 4312365
./qap 4 Datos/sko100c.dat 4312365
./qap 4 Datos/sko100d.dat 4312365
./qap 4 Datos/sko100e.dat 4312365
./qap 4 Datos/wil50.dat 4312365